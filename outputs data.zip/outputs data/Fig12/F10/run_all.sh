#!/bin/bash

rm -r processor*
rm -r postProcessing

foamListTimes -rm

topoSet

decomposePar

mpirun -np 16 simpleFoam -parallel

reconstructPar -latestTime


